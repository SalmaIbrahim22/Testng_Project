package Pages;

import Utilities.Utilities;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class SearchPage {
    private final WebDriver driver;
    public By linksFields = By.className("f-icon arrow-head-down-icon");
    
    public By searchField = By.id("txt_search_query");
    public By searchButton = By.className("f-icon search-icon");
    public By nextPage = By.xpath("//a[@id='next']");
    public By suggestionButtons = By.xpath("//https://www.nagwa.com/ar/lessons/279172803469/]");
    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    public int getLinksCount() throws Exception {

        int countOfLinks = 0;
        List<WebElement> links = driver.findElements(linksFields);
        countOfLinks = links.size();
        return countOfLinks;
    }

    public SearchPage searchByWord(String word) throws Exception {

        Utilities.waitAndEnterTextInWebElement(word, searchField, driver);
        Utilities.waitAndClickOnWebElement(searchButton, driver);

        return new SearchPage(driver);

    }

    public SearchPage goToNextPage() throws Exception {
        Utilities.waitAndScrollUntilFindElement(nextPage, driver);
        Utilities.waitAndClickOnWebElement(nextPage, driver);

        return new SearchPage(driver);

    }

    public List<WebElement> getSuggestionText() throws Exception {
        Utilities.waitAndScrollUntilFindElement(nextPage, driver);
        Utilities.waitAndClickOnWebElement(nextPage, driver);
        List<WebElement> links;
        links = driver.findElements(suggestionButtons);

        return links;

    }
}
